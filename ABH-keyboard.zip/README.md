# ABH Voice Keyboard

தமிழ் + English offline voice input keyboard (Android). Whisper (whisper.cpp) பயன்படுத்துகிறது, இணையம் இல்லாமலேயே பேச்சை டைப் செய்யும்.

## APK build செய்வது
1. இந்த files எல்லாவற்றையும் GitHub repo-வில் upload செய்யுங்கள் (`.github` folder உட்பட).
2. Repo-வின் **Actions** tab → **Build APK** → build முடியும் வரை காத்திருங்கள் (சுமார் 10 நிமிடம்).
3. முடிந்ததும் **ABH-keyboard-apk** artifact-ஐ download செய்து, zip-ஐ திறந்து `app-debug.apk`-ஐ போனில் install செய்யுங்கள்.

## போனில் அமைப்பது
1. **ABH Keyboard** app-ஐ திறந்து: mic permission → keyboard enable → keyboard select → model download (Wi-Fi-யில்).
2. எந்த app-லும் text box-ஐ தொட்டால், 🌐 மூலம் ABH keyboard-க்கு மாறலாம்.
3. 🎤 தொட்டுப் பேசி, மீண்டும் தொட்டு நிறுத்தினால் text வரும். **Auto / தமிழ் / English** பட்டன் மூலம் மொழியைத் தேர்வு செய்யலாம்.

## குறிப்புகள்
- இது voice-only keyboard. சாதாரண டைப்பிங்கிற்கு 🌐 மூலம் Gboard-க்கு மாறுங்கள்.
- முதலில் ஒருமுறை model download செய்ய இணையம் தேவை. அதன் பிறகு எல்லாம் offline.
- தமிழ்-English கலந்து பேசினால் Whisper ஒரு நேரத்தில் ஒரு மொழியை முன்னுரிமை கொடுக்கும். துல்லியம் குறைந்தால் மொழியை கையால் தேர்வு செய்யுங்கள்.
