#include <jni.h>
#include <string>
#include "whisper.h"

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_abh_keyboard_WhisperBridge_nativeInit(JNIEnv *env, jobject, jstring path) {
    const char *p = env->GetStringUTFChars(path, nullptr);
    whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    whisper_context *ctx = whisper_init_from_file_with_params(p, cp);
    env->ReleaseStringUTFChars(path, p);
    return reinterpret_cast<jlong>(ctx);
}

JNIEXPORT void JNICALL
Java_com_abh_keyboard_WhisperBridge_nativeFree(JNIEnv *, jobject, jlong handle) {
    if (handle != 0) {
        whisper_free(reinterpret_cast<whisper_context *>(handle));
    }
}

// Returns UTF-8 bytes (decoded safely on the Kotlin side).
JNIEXPORT jbyteArray JNICALL
Java_com_abh_keyboard_WhisperBridge_nativeTranscribe(JNIEnv *env, jobject, jlong handle,
                                                     jfloatArray audio, jstring lang,
                                                     jint threads) {
    auto *ctx = reinterpret_cast<whisper_context *>(handle);
    jsize n = env->GetArrayLength(audio);
    jfloat *data = env->GetFloatArrayElements(audio, nullptr);
    const char *l = env->GetStringUTFChars(lang, nullptr);

    whisper_full_params wp = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    wp.print_progress = false;
    wp.print_realtime = false;
    wp.print_timestamps = false;
    wp.print_special = false;
    wp.translate = false;
    wp.language = l;  // "auto", "ta" or "en"
    wp.n_threads = threads;
    wp.no_context = true;
    wp.suppress_blank = true;
    wp.no_timestamps = true;
    wp.single_segment = true;

    // Speed: no temperature fallback (it re-decodes up to 6x), single greedy candidate.
    wp.temperature_inc = 0.0f;
    wp.greedy.best_of = 1;

    // Speed: Whisper normally encodes a fixed 30 s window (1500 ctx = 30 s).
    // Encode only as much as was recorded (50 ctx per second) plus padding.
    int ctxNeeded = static_cast<int>(n / 16000.0 * 50.0) + 150;
    if (ctxNeeded < 384) ctxNeeded = 384;
    if (ctxNeeded > 1500) ctxNeeded = 1500;
    wp.audio_ctx = ctxNeeded;

    std::string out;
    if (whisper_full(ctx, wp, data, n) == 0) {
        int segments = whisper_full_n_segments(ctx);
        for (int i = 0; i < segments; i++) {
            out += whisper_full_get_segment_text(ctx, i);
        }
    }

    env->ReleaseStringUTFChars(lang, l);
    env->ReleaseFloatArrayElements(audio, data, JNI_ABORT);

    jbyteArray result = env->NewByteArray(static_cast<jsize>(out.size()));
    env->SetByteArrayRegion(result, 0, static_cast<jsize>(out.size()),
                            reinterpret_cast<const jbyte *>(out.data()));
    return result;
}

}  // extern "C"
