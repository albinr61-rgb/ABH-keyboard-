package com.abh.keyboard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Small setup screen: mic permission, enable keyboard, download the Whisper model. */
class MainActivity : Activity() {

    private lateinit var info: TextView
    private lateinit var progress: ProgressBar

    @Volatile
    private var downloading = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }

        root.addView(TextView(this).apply {
            text = "ABH Voice Keyboard"
            textSize = 24f
        })
        root.addView(TextView(this).apply {
            text = "Tamil + English offline voice input. Keezhe 1 to 4 steps-ai order-la seiyyunga."
            setPadding(0, 16, 0, 24)
        })

        root.addView(button("1. Mic permission kudu") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })
        root.addView(button("2. Keyboard-ai enable pannu") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        root.addView(button("3. Keyboard-ai select pannu") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        ModelStore.models.forEach { m ->
            root.addView(button("4. Download: ${m.label}") { download(m) })
        }

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
        }
        root.addView(progress)

        info = TextView(this).apply { setPadding(0, 24, 0, 0) }
        root.addView(info)

        setContentView(ScrollView(this).apply { addView(root) })
        refreshInfo()
    }

    override fun onResume() {
        super.onResume()
        refreshInfo()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshInfo()
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun refreshInfo() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val model = ModelStore.best(this)
        info.text = buildString {
            append("Mic permission: ").append(if (mic) "OK" else "illai").append('\n')
            append("Model: ").append(model?.name ?: "download aagala")
        }
    }

    private fun download(model: ModelStore.Model) {
        if (downloading) return
        downloading = true
        progress.progress = 0
        info.text = "Download aagudhu: ${model.label}\nWi-Fi-la irukkiradhai urudhi pannunga."

        Thread {
            val target = ModelStore.fileFor(this, model)
            val part = File(target.absolutePath + ".part")
            try {
                val conn = URL(model.url).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000
                conn.readTimeout = 30000
                val total = conn.contentLengthLong
                conn.inputStream.use { input ->
                    part.outputStream().use { output ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var lastPct = -1
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt()
                                if (pct != lastPct) {
                                    lastPct = pct
                                    runOnUiThread { progress.progress = pct }
                                }
                            }
                        }
                    }
                }
                if (target.exists()) target.delete()
                part.renameTo(target)
                runOnUiThread {
                    downloading = false
                    progress.progress = 100
                    refreshInfo()
                }
            } catch (e: Exception) {
                part.delete()
                runOnUiThread {
                    downloading = false
                    info.text = "Download fail aachu: ${e.message}\nThirumba try pannunga."
                }
            }
        }.start()
    }
}
