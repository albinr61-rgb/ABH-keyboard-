package com.abh.keyboard

import android.Manifest
import android.content.pm.PackageManager
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import java.util.concurrent.Executors

class VoiceKeyboardService : InputMethodService() {

    private enum class Lang(val code: String, val label: String) {
        AUTO("auto", "Auto"),
        TA("ta", "தமிழ்"),
        EN("en", "English")
    }

    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var bridge: WhisperBridge? = null
    private var loadedModelPath: String? = null
    private var recorder: Recorder? = null
    private var busy = false
    private var lang = Lang.AUTO

    private lateinit var status: TextView
    private lateinit var mic: Button
    private lateinit var langBtn: Button

    override fun onCreateInputView(): View {
        val v = layoutInflater.inflate(R.layout.keyboard_view, null)
        status = v.findViewById(R.id.status)
        mic = v.findViewById(R.id.mic)
        langBtn = v.findViewById(R.id.lang)

        langBtn.text = lang.label
        langBtn.setOnClickListener {
            lang = Lang.values()[(lang.ordinal + 1) % Lang.values().size]
            langBtn.text = lang.label
        }
        mic.setOnClickListener { onMicClicked() }
        v.findViewById<Button>(R.id.space).setOnClickListener {
            currentInputConnection?.commitText(" ", 1)
        }
        v.findViewById<Button>(R.id.back).setOnClickListener {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        v.findViewById<Button>(R.id.enter).setOnClickListener {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        v.findViewById<Button>(R.id.switcher).setOnClickListener {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        return v
    }

    private fun onMicClicked() {
        if (busy) return

        val active = recorder
        if (active == null) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                setStatus("ABH Keyboard app-a thirandhu mic permission kudunga")
                return
            }
            if (ModelStore.best(this) == null) {
                setStatus("Model illai. ABH Keyboard app-la download pannunga")
                return
            }
            recorder = Recorder().also { it.start() }
            mic.text = "⏹  நிறுத்து / Stop"
            setStatus("Ketkkuren... pesunga")
        } else {
            recorder = null
            val samples = active.stop()
            mic.text = "🎤  பேசு / Speak"
            if (samples.size < 16000) {
                setStatus("Romba short. Innum konjam neram pesunga")
                return
            }
            transcribe(samples)
        }
    }

    private fun transcribe(samples: FloatArray) {
        busy = true
        mic.isEnabled = false
        val startedAt = SystemClock.elapsedRealtime()
        val ticker = object : Runnable {
            override fun run() {
                if (!busy) return
                val s = (SystemClock.elapsedRealtime() - startedAt) / 1000
                setStatus("Type aagudhu... ${s}s")
                ui.postDelayed(this, 1000)
            }
        }
        ui.post(ticker)
        val langCode = lang.code
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)

        worker.execute {
            val text = try {
                val b = ensureBridge()
                b?.transcribe(samples, langCode, threads)
            } catch (e: Throwable) {
                null
            }
            ui.post {
                busy = false
                mic.isEnabled = true
                if (text == null) {
                    setStatus("Model load aagala. App-la thirumba download pannunga")
                } else if (text.isBlank()) {
                    setStatus("Onnum ketkala. Thirumba try pannunga")
                } else {
                    currentInputConnection?.commitText(text.trim() + " ", 1)
                    setStatus("Mudinjadhu. Innoru thadavai pesalam")
                }
            }
        }
    }

    private fun ensureBridge(): WhisperBridge? {
        val file = ModelStore.best(this) ?: return null
        val path = file.absolutePath
        if (bridge != null && loadedModelPath == path) return bridge
        bridge?.close()
        val b = WhisperBridge(path)
        if (!b.isLoaded) {
            bridge = null
            loadedModelPath = null
            return null
        }
        bridge = b
        loadedModelPath = path
        return b
    }

    private fun setStatus(msg: String) {
        if (::status.isInitialized) status.text = msg
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        recorder?.let {
            recorder = null
            it.stop()
            if (::mic.isInitialized) mic.text = "🎤  பேசு / Speak"
        }
    }

    override fun onDestroy() {
        worker.execute {
            bridge?.close()
            bridge = null
        }
        worker.shutdown()
        super.onDestroy()
    }
}
