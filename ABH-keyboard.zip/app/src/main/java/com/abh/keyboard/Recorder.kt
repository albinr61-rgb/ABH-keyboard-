package com.abh.keyboard

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder

/** Records 16 kHz mono audio, which is what Whisper expects. */
class Recorder {

    private val sampleRate = 16000

    @Volatile
    private var running = false
    private val chunks = ArrayList<ShortArray>()
    private var thread: Thread? = null

    @SuppressLint("MissingPermission")
    fun start() {
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, sampleRate * 2)
        )
        chunks.clear()
        running = true
        rec.startRecording()
        thread = Thread {
            val buf = ShortArray(4096)
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) synchronized(chunks) { chunks.add(buf.copyOf(n)) }
            }
            rec.stop()
            rec.release()
        }.also { it.start() }
    }

    fun stop(): FloatArray {
        running = false
        thread?.join()
        thread = null
        synchronized(chunks) {
            val total = chunks.sumOf { it.size }
            val out = FloatArray(total)
            var i = 0
            for (c in chunks) for (s in c) out[i++] = s / 32768f
            chunks.clear()
            return out
        }
    }
}
