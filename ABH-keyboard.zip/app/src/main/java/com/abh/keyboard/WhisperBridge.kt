package com.abh.keyboard

class WhisperBridge(modelPath: String) {

    private var handle: Long = nativeInit(modelPath)

    val isLoaded: Boolean get() = handle != 0L

    fun transcribe(audio: FloatArray, langCode: String, threads: Int): String {
        if (handle == 0L) return ""
        val bytes = nativeTranscribe(handle, audio, langCode, threads)
        return String(bytes, Charsets.UTF_8)
    }

    fun close() {
        if (handle != 0L) {
            nativeFree(handle)
            handle = 0L
        }
    }

    private external fun nativeInit(path: String): Long
    private external fun nativeFree(handle: Long)
    private external fun nativeTranscribe(
        handle: Long,
        audio: FloatArray,
        lang: String,
        threads: Int
    ): ByteArray

    companion object {
        init {
            System.loadLibrary("abhwhisper")
        }
    }
}
