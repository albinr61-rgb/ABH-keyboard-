package com.abh.keyboard

import android.content.Context
import java.io.File

object ModelStore {

    data class Model(val file: String, val url: String, val label: String)

    private const val BASE = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"

    val models = listOf(
        Model("ggml-base-q5_1.bin", BASE + "ggml-base-q5_1.bin", "Base q5 (~60 MB, romba vegam, Tamil accuracy kammi)"),
        Model("ggml-small-q5_1.bin", BASE + "ggml-small-q5_1.bin", "Small q5 (~181 MB, nalla balance)"),
        Model("ggml-small.bin", BASE + "ggml-small.bin", "Small full (~466 MB, romba methuvu)")
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("abh", Context.MODE_PRIVATE)

    fun dir(ctx: Context): File = File(ctx.filesDir, "models").apply { mkdirs() }

    fun fileFor(ctx: Context, model: Model): File = File(dir(ctx), model.file)

    fun select(ctx: Context, model: Model) {
        prefs(ctx).edit().putString("model", model.file).apply()
    }

    private fun usable(f: File) = f.exists() && f.length() > 1_000_000

    /** The model the user picked, else the first downloaded one (fastest first). */
    fun best(ctx: Context): File? {
        val chosen = prefs(ctx).getString("model", null)
        models.firstOrNull { it.file == chosen }
            ?.let { fileFor(ctx, it) }
            ?.takeIf { usable(it) }
            ?.let { return it }
        return models.map { fileFor(ctx, it) }.firstOrNull { usable(it) }
    }
}
