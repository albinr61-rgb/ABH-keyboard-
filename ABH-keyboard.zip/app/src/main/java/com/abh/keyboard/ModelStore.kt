package com.abh.keyboard

import android.content.Context
import java.io.File

object ModelStore {

    data class Model(val file: String, val url: String, val label: String)

    private const val BASE = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"

    // Ordered from smallest to largest. The largest one that is downloaded gets used.
    val models = listOf(
        Model("ggml-small-q5_1.bin", BASE + "ggml-small-q5_1.bin", "Small q5 (~181 MB, vegam)"),
        Model("ggml-small.bin", BASE + "ggml-small.bin", "Small full (~466 MB, accuracy adhigam)")
    )

    fun dir(ctx: Context): File = File(ctx.filesDir, "models").apply { mkdirs() }

    fun fileFor(ctx: Context, model: Model): File = File(dir(ctx), model.file)

    fun best(ctx: Context): File? =
        models.reversed()
            .map { fileFor(ctx, it) }
            .firstOrNull { it.exists() && it.length() > 1_000_000 }
}
